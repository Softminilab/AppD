//
//  AppDelegate.swift
//  AppD
//
//  Created by 0x2ab70001b1 on 2024/7/26.
//

import UIKit
import ADEUMInstrumentation


@main
class AppDelegate: UIResponder, UIApplicationDelegate {



    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        let config = ADEumAgentConfiguration(appKey: "AD-AAB-ADF-VVV")
        // Configure the iOS Agent to report the metrics and screenshots

        // to the SaaS EUM Server in Americas

        config.collectorURL = "https://col.eum-appdynamics.com"
        config.screenshotURL = "https://image.eum-appdynamics.com"
        config.loggingLevel = .all
        ADEumInstrumentation.initWith(config)
        return true
    }
}

