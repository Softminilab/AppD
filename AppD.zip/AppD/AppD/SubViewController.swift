//
//  ViewController.swift
//  AppD
//
//  Created by 0x2ab70001b1 on 2024/7/26.
//

import UIKit
import ADEUMInstrumentation

class SubViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .gray
        ADEumInstrumentation.leaveBreadcrumb("Enter SubViewController(ViewdidLoad)...", mode: ADEumBreadcrumbVisibility.crashesAndSessions)
    }
}

