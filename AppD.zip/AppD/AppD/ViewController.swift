//
//  ViewController.swift
//  AppD
//
//  Created by 0x2ab70001b1 on 2024/7/26.
//

import UIKit
import ADEUMInstrumentation

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        makeUI()
        ADEumInstrumentation.leaveBreadcrumb("Enter ViewController(ViewdidLoad)", mode: ADEumBreadcrumbVisibility.crashesAndSessions)
        ADEumInstrumentation.setUserData("Mark！！", value: getCurrentDataTimeString())
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        ADEumInstrumentation.stopTimer(withName: "ViewController")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        ADEumInstrumentation.startTimer(withName: "ViewController")
    }
    
    private func makeUI() {
        view.backgroundColor = .yellow
        
        let btn = UIButton(type: .custom)
        btn.setTitle("Sub VC", for: .normal)
        btn.setTitleColor(UIColor.black, for: .normal)
        btn.sizeToFit()
        btn.center = self.view.center
        btn.addTarget(self, action: #selector(intoSubVC), for: .touchUpInside)
        view.addSubview(btn)
        
        let nextSession = UIButton(type: .custom)
        nextSession.setTitle("Start next session", for: .normal)
        nextSession.setTitleColor(UIColor.black, for: .normal)
        nextSession.sizeToFit()
        nextSession.center = CGPoint(x: self.view.center.x, y: self.view.center.y + 100)
        nextSession.addTarget(self, action: #selector(startNextSession), for: .touchUpInside)
        view.addSubview(nextSession)
        
        let shutdownAgentBtn = UIButton(type: .custom)
        shutdownAgentBtn.setTitle("Shutdown Agent", for: .normal)
        shutdownAgentBtn.setTitleColor(UIColor.black, for: .normal)
        shutdownAgentBtn.sizeToFit()
        shutdownAgentBtn.center = CGPoint(x: self.view.center.x, y: self.view.center.y + 200)
        shutdownAgentBtn.addTarget(self, action: #selector(shutdownAgent), for: .touchUpInside)
        view.addSubview(shutdownAgentBtn)
        
        let restartAgentBtn = UIButton(type: .custom)
        restartAgentBtn.setTitle("Restart Agent", for: .normal)
        restartAgentBtn.setTitleColor(UIColor.black, for: .normal)
        restartAgentBtn.sizeToFit()
        restartAgentBtn.center = CGPoint(x: self.view.center.x, y: self.view.center.y + 300)
        restartAgentBtn.addTarget(self, action: #selector(restartAgent), for: .touchUpInside)
        view.addSubview(restartAgentBtn)
    }
    
    @objc private func intoSubVC() {
        ADEumInstrumentation.leaveBreadcrumb("Tap intoSubVC Button", mode: ADEumBreadcrumbVisibility.crashesAndSessions)
        self.present(SubViewController(), animated: true)
    }
    
    @objc private func startNextSession() {
        ADEumInstrumentation.leaveBreadcrumb("Tap startNextSession Button", mode: ADEumBreadcrumbVisibility.crashesAndSessions)
        ADEumInstrumentation.startNextSession()
        ADEumInstrumentation.leaveBreadcrumb("Start Next Session", mode: ADEumBreadcrumbVisibility.crashesAndSessions)
    }
    
    @objc private func shutdownAgent() {
        ADEumInstrumentation.leaveBreadcrumb("Tap shutdownAgent Button", mode: ADEumBreadcrumbVisibility.crashesAndSessions)
        ADEumInstrumentation.leaveBreadcrumb("Will shutdown agent", mode: ADEumBreadcrumbVisibility.crashesAndSessions)
        ADEumInstrumentation.shutdownAgent()
        ADEumInstrumentation.leaveBreadcrumb("Later shutdown agent", mode: ADEumBreadcrumbVisibility.crashesAndSessions)
    }
    
    @objc private func restartAgent() {
        ADEumInstrumentation.leaveBreadcrumb("Tap restartAgent Button", mode: ADEumBreadcrumbVisibility.crashesAndSessions)
        ADEumInstrumentation.leaveBreadcrumb("Will restart agent", mode: ADEumBreadcrumbVisibility.crashesAndSessions)
        ADEumInstrumentation.restartAgent()
        ADEumInstrumentation.leaveBreadcrumb("Later restartAgent", mode: ADEumBreadcrumbVisibility.crashesAndSessions)
    }
    
    private func getCurrentDataTimeString() -> String {
        let date = Date()
        let calendar = Calendar.current
        let month = calendar.component(.month, from: date)
        let hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        let second = calendar.component(.second, from: date)
        return "\(month)-\(hour)-\(minutes)-\(second)"
    }
}

